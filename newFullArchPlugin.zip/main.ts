import { App, Editor, MarkdownView, Modal, Notice, Plugin, PluginSettingTab, Setting } from 'obsidian';
import * as child_process from "child_process";
import * as fs from "fs";


export default class ProSPlugin extends Plugin {

	async onload() {
		this.addCommand({id: 'pros-edit-comd', name: 'zuza editor', editorCallback: (editor: Editor, view: MarkdownView) => {
			//abc
			//abc

//			const xx = editor.getLine(0)

			const linesCount = editor.lineCount();
//			console.log(linesCount)
			//fs.promises.writeFile('/home/pros/zszszszXXXX', linesCount.toString())
//			fs.promises.writeFile('/home/pros/zszszszXXXX', xx)


			var arr:string[] = new Array(linesCount) 
//			arr[0] = 'abc'
//			console.log(arr[0])

			for (var i = 0; i < linesCount; i++)
			{
				arr[i] = editor.getLine(i)
			}
			var str = ""
			for (var i = 0; i < linesCount; i++)
			{
				str = str + arr[i] + "\n";
			}
//			console.log("FINALE")
//			console.log(str)

			
			var fileToWriteConst = '/home/pros/.0dev/Scripts/obshackee/obsActiveFile'
			var startScriptConst = '/home/pros/.0dev/Scripts/obshackee/start.sh'
			//fs.promises.writeFile('/home/pros/.1_Programming/Scripts/hackee/obsActiveFile', str)
//			fs.promises.writeFile('/home/pros/.1_Programming/Scripts/hackee/obsActiveFile', str)
			fs.promises.writeFile(fileToWriteConst, str)


//							const proc = child_process.spawn('alacritty', [ '-e', '/home/pros/.1_Programming/Scripts/hackee/hackeeStart.sh', '/home/pros/.0dev/Scripts/hackee/obsActiveFile' ]);

			console.log("BEFORE")
							const proc = child_process.spawn('alacritty', [ '-e', startScriptConst, fileToWriteConst ]);
			console.log("OVERHERE!!!")




			//New part I start:
			

			//okay, next thing is ... follow my plan

			//FUCK, below was for nothing

			
			//FUCK!!! so, I want to look for pattern: **Example _SOME_NUMBER, ANY AMOUNT OF NUMBER, d+ start then goes whatever!
			


//			const proc = child_process.spawn('/home/pros/.jdks/openjdk-19.0.2/bin/java', [ '--version' ]);
//			const proc = child_process.spawn('/bin/sh', [ '/home/pros/.1_Programming/Scrips/hackee/hackeeStart.sh', '--versionX' ]);
							//
				//const proc = child_process.spawn('alacritty', [ '-e', '/home/pros/.1_Programming/Scripts/hackee/hackeeStart.sh', '/home/pros/.1_Programming/Scripts/hackee/hackeeStart.sh' ]);


			//proc.stdout.on('data', (data) => {
			//	console.log('MY WORKING EX: ' + data)
			//})
			



	//THIS WORKS!!!
//	const alac = child_process.spawn('alacritty');		
	//console.log('PROS:' + child.stdout)
	//child.stdout.on('data', (data) => {
//		console.log('stdout: ${data}')
	//	console.log('stdout: ' + data)

	//})

			

			// var str = 'someStringToTest'
			const count = (ss) => {
				//const re = /[a-z]{3}/g
//				const re = "\*\* Example \d+ start"
//				const re = "\\*\\* Example \\d+ start"
				//const re = /\*\* Example \d start\*\*/

				//const re = /aa55/g
//				const re = /\*\* aaa/g
				const re = /\*\*Example \d+ start\*\*/g

				//const re = /exex/g
				//const re = new RegEx/** Example \\d+ start/

				

				return ((ss || '').match(re) || []).length
		
			}

			var yy = count(str)
		//	console.log(yy)
		//	console.log("Look above")









	// const sel = editor.getDoc() //returns Object
	const sel = editor.getLine(8)
    //const sel = editor.getSelection()
	//
	
	
	  //console.log('Special Force?')

   // console.log('You have selected: ${sel}');
	//console.log('You have selected: ' + sel);


	//const x = editor.createEl("h1", { text: "Heading 1" });
	


//					const child = child_process.spawn("java", ["--version"], {env: process.env, shell: this.usesShell});
//										const child = child_process.exec('java', ['--version'], {env: process.env, shell: this.usesShell});
	//THIS EXEC IS KIND OF OKAY?
	//const child = child_process.exec('java', ['--version']);
	//const child = child_process.spawn('java', ['--version']);

	//const child = child_process.spawn('ls');	//this works, and with stdout
	//const child = child_process.spawn('/usr/share/java');	//this works, and with stdout
	//const child = child_process.spawn('ls', [ '/home/pros' ]);	//this works TOO, I have access to filesystem!!!
	
	//this was last for me
	//const child = child_process.spawn('/home/pros/.jdks/openjdk-19.0.2/bin/java', [ '--version' ]);	



	//THIS WORKS!!!
//	const alac = child_process.spawn('alacritty');		
	//console.log('PROS:' + child.stdout)
	//child.stdout.on('data', (data) => {
//		console.log('stdout: ${data}')
	//	console.log('stdout: ' + data)

	//})


//	fs.promises.writeFile(tempFileName, codeBlockContent).then(() => {
	//fs.promises.writeFile('/home/pros/zszszsz', 'helloMan?').then(() => {	//THIS FUCKING WORKS!!! I can write to a file!!!

	//	console.log('I wrote to file?')
	//})





	//console.log('new log, it works')
  },
})

//this is end of load method
	}

	async onunload() {
	    console.log('out')
	}
}

